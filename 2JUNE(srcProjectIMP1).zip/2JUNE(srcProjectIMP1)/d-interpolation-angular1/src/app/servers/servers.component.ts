import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {

  constructor() { 
    setTimeout(() => {
      this.allowNewServer = false;
    }, 5000);


    
  }
 
  allowNewServer : boolean = true;
  serverCreationStatus : string = "No Server was creaed";
  serverName :string =  "";

  onCreateServer(){
    this.serverCreationStatus = "Server was Created !!";
  }

  onUpdateServerName(event : Event){
    this.serverName = (<HTMLInputElement> event.target).value;
  }

  ngOnInit(): void {
  }

  

}
