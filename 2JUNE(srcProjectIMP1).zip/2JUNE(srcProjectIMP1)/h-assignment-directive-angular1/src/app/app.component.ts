import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'h-assignment-directive-angular';
  
  showToggle: boolean = false;
  count: number = 0;
  status: string = "";
  counter: number [] =[];
  numbersArray: number [] =[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];
  
  onToggleDisplay(){
    this.showToggle = !this.showToggle;
    this.count = this.count+1;
    this.counter.push(this.count);
    
  }

 getColor(count : number){
   return count > 5 ? 'blue': 'transparent' ;
 }

 
}
