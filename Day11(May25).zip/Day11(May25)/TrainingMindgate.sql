CREATE TABLE employee (
    employee_id     NUMBER(10),
    first_name      VARCHAR(20),
    last_name       VARCHAR(20),
    department_name VARCHAR(20),
    salary          NUMBER(20, 2)
);

ALTER TABLE employee ADD joining_date DATE;

DESC employee;

ALTER TABLE employee DROP COLUMN joining_date;

CREATE TABLE employee (
    employee_id     NUMBER(10) NOT NULL,
    first_name      VARCHAR(20) NOT NULL,
    last_name       VARCHAR(20) NOT NULL,
    department_name VARCHAR(20) NOT NULL,
    salary          NUMBER(20, 2) NOT NULL
);

DROP TABLE employee;

INSERT INTO employee VALUES (
    101,
    'Vivek',
    'Gohil',
    'Training',
    1000
);

CREATE TABLE purchase_order (
    purchase_order_id NUMBER(10) PRIMARY KEY,
    company_name      VARCHAR(50) NOT NULL,
    amount            NUMBER(10, 2) NOT NULL
);

DESC purchase_order;

SELECT
    *
FROM
    user_constraints;

SELECT
    *
FROM
    user_constraints
WHERE
    table_name = 'PURCHASE_ORDER';

DROP TABLE purchase_order;

CREATE TABLE purchase_order (
    purchase_order_id NUMBER(10),
    company_name      VARCHAR(50) NOT NULL,
    amount            NUMBER(10, 2) NOT NULL,
    CONSTRAINT pk_purchase_order_id PRIMARY KEY ( purchase_order_id )
);

DROP TABLE employee;

CREATE TABLE project_details (
    project_id NUMBER(10),
    name       VARCHAR(20),
    start_date DATE,
    end_date   DATE,
    CONSTRAINT pk_project_id PRIMARY KEY ( project_id )
);

INSERT INTO project_details VALUES (
    1,
    'PayTM',
    TO_DATE('2022-01-01', 'YYYY-MM-DD'),
    TO_DATE('2025-01-01', 'YYYY-MM-DD')
);

INSERT INTO project_details VALUES (
    2,
    'PhonePay',
    TO_DATE('2022-01-01', 'YYYY-MM-DD'),
    TO_DATE('2025-01-01', 'YYYY-MM-DD')
);

INSERT INTO project_details VALUES (
    3,
    'GPay',
    TO_DATE('2022-01-01', 'YYYY-MM-DD'),
    TO_DATE('2025-01-01', 'YYYY-MM-DD')
);

COMMIT;

CREATE TABLE employee (
    employee_id NUMBER(10),
    name        VARCHAR(50),
    salary      NUMBER(10, 2),
    project_id  NUMBER(10),
    CONSTRAINT pk_employee_id PRIMARY KEY ( employee_id ),
    CONSTRAINT fk_project_id FOREIGN KEY ( project_id )
        REFERENCES project_details ( project_id )
);

INSERT INTO employee VALUES (
    101,
    'Vivek Gohil',
    1000,
    1
);

INSERT INTO employee VALUES (
    102,
    'Rohit',
    1000,
    2
);

INSERT INTO employee VALUES (
    103,
    'Priyanka',
    1000,
    3
);

INSERT INTO employee VALUES (
    104,
    'Santosh',
    1000,
    2
);

INSERT INTO employee VALUES (
    105,
    'Shubham',
    1000,
    2
);

INSERT INTO employee VALUES (
    106,
    'Shashank',
    1000,
    2
);

INSERT INTO employee VALUES (
    107,
    'Miraj',
    1000,
    2
);

COMMIT;

DELETE FROM project_details
WHERE
    project_id = 1;

DROP TABLE employee;

COMMIT;

CREATE TABLE employee (
    employee_id    NUMBER(10),
    name           VARCHAR(20) NOT NULL,
    contact_number VARCHAR(10) NOT NULL UNIQUE,
    salary         VARCHAR(20)
);

INSERT INTO employee VALUES (
    101,
    'Test 1',
    '9632103241',
    1000
);

INSERT INTO employee VALUES (
    101,
    'Test2',
    '96324123641',
    1000
);

DROP TABLE employee;

CREATE TABLE employee (
    employee_id    VARCHAR(10) CHECK ( employee_id LIKE 'MGS%' ),
    name           VARCHAR(20) NOT NULL,
    contact_number VARCHAR(10) NOT NULL UNIQUE,
    salary         VARCHAR(20) CHECK ( salary > 0 )
);

INSERT INTO employee VALUES (
    'MGS101',
    'Test 1',
    '9632103241',
    1000
);

INSERT INTO employee VALUES (
    'MGS102',
    'Test2',
    '9632412364',
    2000
);

CREATE TABLE employee (
    employee_id    VARCHAR(10),
    name           VARCHAR(20) NOT NULL,
    contact_number VARCHAR(10) NOT NULL,
    salary         VARCHAR(20),
    city           VARCHAR(20) DEFAULT 'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS101',
    'Vivek Gohil',
    '9638527413',
    1000, DEFAULT
);

INSERT INTO employee (
    employee_id,
    name,
    contact_number,
    salary
) VALUES (
    'MGS102',
    'Priyanka',
    '1234569784',
    9000
);

SELECT
    *
FROM
    employee;

CREATE TABLE client_master (
    client_no VARCHAR(6),
    name      VARCHAR(20),
    address1  VARCHAR(30),
    address2  VARCHAR(30),
    city      VARCHAR(15),
    state     VARCHAR(15),
    pincode   NUMBER(6),
    bal_due   NUMBER(10, 2),
    CONSTRAINT pk_client_no PRIMARY KEY ( client_no )
);

DROP TABLE client_master;

CREATE TABLE client_master (
    client_no VARCHAR(6) CHECK ( client_no LIKE 'C%' ),
    name      VARCHAR(20),
    address1  VARCHAR(30),
    address2  VARCHAR(30),
    city      VARCHAR(15),
    state     VARCHAR(15),
    pincode   NUMBER(6),
    bal_due   NUMBER(10, 2),
    CONSTRAINT pk_client_no PRIMARY KEY ( client_no )
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00001',
    'Ivan Bayross',
    'Bombay',
    400054,
    'Maharashtra',
    15000
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00002',
    'Vandana Saitwal',
    'Madras',
    780001,
    'Tamil Nadu',
    0
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00003',
    'Pramada Jaguste',
    'Bombay',
    400057,
    'Maharashtra',
    5000
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00004',
    'Basu Navindgi',
    'Bombay',
    400056,
    'Maharashtra',
    0
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00005',
    'Ravi Sreedharan',
    'Delhi',
    100001,
    'Delhi',
    2000
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00006',
    'Rukmini',
    'Bombay',
    400050,
    'Maharashtra',
    0
);

SELECT
    *
FROM
    client_master;

COMMIT;

CREATE TABLE client_master (
    client_no VARCHAR(6) CHECK ( client_no LIKE 'C%' ),
    name      VARCHAR(20) NOT NULL,
    address1  VARCHAR(30),
    address2  VARCHAR(30),
    city      VARCHAR(15),
    state     VARCHAR(15),
    pincode   NUMBER(6),
    bal_due   NUMBER(10, 2),
    CONSTRAINT pk_client_no PRIMARY KEY ( client_no )
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00001',
    'Ivan Bayross',
    'Bombay',
    400054,
    'Maharashtra',
    15000
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00002',
    'Vandana Saitwal',
    'Madras',
    780001,
    'Tamil Nadu',
    0
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00003',
    'Pramada Jaguste',
    'Bombay',
    400057,
    'Maharashtra',
    5000
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00004',
    'Basu Navindgi',
    'Bombay',
    400056,
    'Maharashtra',
    0
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00005',
    'Ravi Sreedharan',
    'Delhi',
    100001,
    'Delhi',
    2000
);

INSERT INTO client_master (
    client_no,
    name,
    city,
    pincode,
    state,
    bal_due
) VALUES (
    'C00006',
    'Rukmini',
    'Bombay',
    400050,
    'Maharashtra',
    0
);

SELECT
    *
FROM
    client_master;

COMMIT;

CREATE TABLE product_master (
    product_no     VARCHAR(6) CHECK ( product_no LIKE 'P%' ),
    description    VARCHAR(50) NOT NULL,
    profit_percent NUMBER(3, 2) NOT NULL,
    unit_measure   VARCHAR(10) NOT NULL,
    record_lvl     NUMBER(8) NOT NULL,
    sell_price     NUMBER(8, 2) NOT NULL CHECK ( sell_price > 0 ),
    cost_price     NUMBER(8, 2) NOT NULL CHECK ( cost_price > 0 ),
    qty_on_hand    NUMBER(3),
    CONSTRAINT pk_product_no PRIMARY KEY ( product_no )
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P00001',
    '1.44 Floppies',
    5,
    'Piece',
    100,
    20,
    525,
    500
);

SELECT
    *
FROM
    product_master;

DROP TABLE product_master;

CREATE TABLE product_master (
    product_no     VARCHAR(6) CHECK ( product_no LIKE 'P%' ),
    description    VARCHAR(50) NOT NULL,
    profit_percent NUMBER(3, 2) NOT NULL,
    unit_measure   VARCHAR(10) NOT NULL,
    qty_on_hand    NUMBER(3),
    record_lvl     NUMBER(8) NOT NULL,
    sell_price     NUMBER(8, 2) NOT NULL CHECK ( sell_price > 0 ),
    cost_price     NUMBER(8, 2) NOT NULL CHECK ( cost_price > 0 ),
    CONSTRAINT pk_product_no PRIMARY KEY ( product_no )
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P00001',
    '1.44 Floppies',
    5,
    'Piece',
    100,
    20,
    525,
    500
);

SELECT
    *
FROM
    product_master;

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P03453',
    'Monitors',
    6,
    'Piece',
    10,
    3,
    12000,
    11280
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P06734',
    'Mouse',
    5,
    'Piece',
    20,
    5,
    1050,
    1000
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P07865',
    '1.22 Floppies',
    5,
    'Piece',
    100,
    20,
    525,
    500
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P07868',
    'Keyboards',
    2,
    'Piece',
    10,
    3,
    3150,
    3050
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P07885',
    'CD Drive',
    2.5,
    'Piece',
    10,
    3,
    5250,
    5100
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P07965',
    '540 HDD',
    4,
    'Piece',
    10,
    3,
    8400,
    8000
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P07975',
    '1.44 Driver',
    5,
    'Piece',
    10,
    3,
    1050,
    1000
);

INSERT INTO product_master (
    product_no,
    description,
    profit_percent,
    unit_measure,
    qty_on_hand,
    record_lvl,
    sell_price,
    cost_price
) VALUES (
    'P08865',
    '1.22 Driver',
    5,
    'Piece',
    2,
    3,
    1050,
    1000
);

SELECT
    *
FROM
    product_master;

COMMIT;

CREATE TABLE salesman_master (
    salesman_no VARCHAR(6) CHECK ( product_no LIKE 'S%' ),
    address1    VARCHAR(30) NOT NULL,
    address2    VARCHAR(30),
    city        VARCHAR(20),
    pincode     NUMBER(6),
    state       VARCHAR(20),
    sal_amt     NUMBER(8, 2) NOT NULL CHECK ( sal_amt > 0 ),
    tgt_to_get  NUMBER(6, 2) NOT NULL CHECK ( tgt_to_get > 0 ),
    ytd_sales   NUMBER(6, 2) NOT NULL,
    CONSTRAINT pk_salesman_no PRIMARY KEY ( salesman_no )
);

CREATE TABLE salesman_master (
    salesman_no   VARCHAR(6) CHECK ( product_no LIKE 'S%' ),
    salesman_name VARCHAR(20) NOT NULL,
    address1      VARCHAR(30) NOT NULL,
    address2      VARCHAR(30),
    city          VARCHAR(20),
    pincode       NUMBER(6),
    state         VARCHAR(20),
    sal_amt       NUMBER(8, 2) NOT NULL CHECK ( sal_amt > 0 ),
    tgt_to_get    NUMBER(6, 2) NOT NULL CHECK ( tgt_to_get > 0 ),
    ytd_sales     NUMBER(6, 2) NOT NULL,
    CONSTRAINT pk_salesman_no PRIMARY KEY ( salesman_no )
);

CREATE TABLE salesman_master (
    salesman_no   VARCHAR(6) CHECK ( product_no LIKE 'S%' ),
    salesman_name VARCHAR(20) NOT NULL,
    address1      VARCHAR(30) NOT NULL,
    address2      VARCHAR(30),
    city          VARCHAR(20),
    pincode       NUMBER(6),
    state         VARCHAR(20),
    sal_amt       NUMBER(8, 2) NOT NULL CHECK ( sal_amt > 0 ),
    tgt_to_get    NUMBER(6, 2) NOT NULL CHECK ( tgt_to_get > 0 ),
    ytd_sales     NUMBER(6, 2) NOT NULL,
    CONSTRAINT pk_salesman_no PRIMARY KEY ( salesman_no )
);

CREATE TABLE salesman_master (
    salesman_no   VARCHAR(6) CHECK ( salesman_no LIKE 'S%' ),
    salesman_name VARCHAR(20) NOT NULL,
    address1      VARCHAR(30) NOT NULL,
    address2      VARCHAR(30),
    city          VARCHAR(20),
    pincode       NUMBER(6),
    state         VARCHAR(20),
    sal_amt       NUMBER(8, 2) NOT NULL CHECK ( sal_amt > 0 ),
    tgt_to_get    NUMBER(6, 2) NOT NULL CHECK ( tgt_to_get > 0 ),
    ytd_sales     NUMBER(6, 2) NOT NULL,
    CONSTRAINT pk_salesman_no PRIMARY KEY ( salesman_no )
);

DROP TABLE salesman_master;

CREATE TABLE salesman_master (
    salesman_no   VARCHAR(6) CHECK ( salesman_no LIKE 'S%' ),
    salesman_name VARCHAR(20) NOT NULL,
    address1      VARCHAR(30) NOT NULL,
    address2      VARCHAR(30),
    city          VARCHAR(20),
    pincode       NUMBER(6),
    state         VARCHAR(20),
    sal_amt       NUMBER(8, 2) NOT NULL CHECK ( sal_amt > 0 ),
    tgt_to_get    NUMBER(6, 2) NOT NULL CHECK ( tgt_to_get > 0 ),
    ytd_sales     NUMBER(6, 2) NOT NULL,
    remarks       VARCHAR(20),
    CONSTRAINT pk_salesman_no PRIMARY KEY ( salesman_no )
);

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00001',
    'Kiran',
    'A/14',
    'Worli',
    'Bombay',
    400002,
    'MAH',
    3000,
    100,
    50,
    'Good'
);

SELECT
    *
FROM
    salesman_master;

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00002',
    'Manish',
    '65',
    'Nariman',
    'Bombay',
    400001,
    'MAH',
    3000,
    200,
    100,
    'Good'
);

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00003',
    'Ravi',
    'P-7',
    'Bandra',
    'Bombay',
    400032,
    'MAH',
    3000,
    200,
    100,
    'Good'
);

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00004',
    'Ashish',
    'A/5',
    'Juhu',
    'Bombay',
    400044,
    'MAH',
    3500,
    200,
    150,
    'Good'
);

SELECT
    *
FROM
    salesman_master;

COMMIT;

DROP TABLE salesman_master;

CREATE TABLE salesman_master (
    salesman_no   VARCHAR(6) CHECK ( salesman_no LIKE 'S%' ),
    salesman_name VARCHAR(20) NOT NULL,
    address1      VARCHAR(30) NOT NULL,
    address2      VARCHAR(30),
    city          VARCHAR(20),
    pincode       NUMBER(6),
    state         VARCHAR(20),
    sal_amt       NUMBER(8, 2) NOT NULL CHECK ( sal_amt > 0 ),
    tgt_to_get    NUMBER(6, 2) NOT NULL CHECK ( tgt_to_get > 0 ),
    ytd_sales     NUMBER(6, 2) NOT NULL,
    remarks       VARCHAR(60),
    CONSTRAINT pk_salesman_no PRIMARY KEY ( salesman_no )
);

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00001',
    'Kiran',
    'A/14',
    'Worli',
    'Bombay',
    400002,
    'MAH',
    3000,
    100,
    50,
    'Good'
);

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00002',
    'Manish',
    '65',
    'Nariman',
    'Bombay',
    400001,
    'MAH',
    3000,
    200,
    100,
    'Good'
);

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00003',
    'Ravi',
    'P-7',
    'Bandra',
    'Bombay',
    400032,
    'MAH',
    3000,
    200,
    100,
    'Good'
);

INSERT INTO salesman_master (
    salesman_no,
    salesman_name,
    address1,
    address2,
    city,
    pincode,
    state,
    sal_amt,
    tgt_to_get,
    ytd_sales,
    remarks
) VALUES (
    'S00004',
    'Ashish',
    'A/5',
    'Juhu',
    'Bombay',
    400044,
    'MAH',
    3500,
    200,
    150,
    'Good'
);

SELECT
    *
FROM
    salesman_master;

COMMIT;

CREATE TABLE sales_order (
    s_order_no   VARCHAR(6) CHECK ( s_order_no LIKE 'O%' ),
    s_order_date DATE,
    client_no    VARCHAR(6),
    dely_addr    VARCHAR(25),
    salesman_no  VARCHAR(6),
    CONSTRAINT pk_s_order_no PRIMARY KEY ( s_order_no ),
    CONSTRAINT fk_client_no FOREIGN KEY ( client_no )
        REFERENCES client_master ( client_no ),
    CONSTRAINT fk_salesman_no FOREIGN KEY ( salesman_no )
        REFERENCES salesman_master ( salesman_no )
);

SELECT
    *
FROM
    sales_order;

CREATE TABLE sales_order (
    s_order_no   VARCHAR2(6) CHECK ( s_order_no LIKE 'O%' ),
    s_order_date DATE,
    client_no    VARCHAR2(6),
    dely_addr    VARCHAR2(25),
    salesman_no  VARCHAR2(6),
    dely_type    CHAR(1) DEFAULT 'F' CHECK ( dely_type = 'P'
                                          OR dely_type = 'F' ),
    billed_yn    CHAR(1) DEFAULT 'N' CHECK ( billed_yn = 'Y'
                                          OR billed_yn = 'N' ),
    dely_date    DATE,
    order_status VARCHAR(10) CHECK ( order_status IN ( 'in process', 'Fulfilled', 'BackOrder', 'Canceled' ) ),
    CONSTRAINT ck_dely_date CHECK ( dely_date > s_order_date ),
    CONSTRAINT pk_s_order_no PRIMARY KEY ( s_order_no ),
    CONSTRAINT fk_client_no FOREIGN KEY ( client_no )
        REFERENCES client_master ( client_no ),
    CONSTRAINT fk_salesman_no FOREIGN KEY ( salesman_no )
        REFERENCES salesman_master ( salesman_no )
);

DESC sales_order

DROP TABLE sales_order;

INSERT INTO sales_order (
    s_order_no,
    s_order_date,
    client_no,
    salesman_no,
    dely_type,
    billed_yn,
    dely_date,
    order_status
) VALUES (
    'O19001',
    TO_DATE('12-JAN-1996', 'DD-MON-YYYY'),
    'C00001',
    'S00001',
    'F',
    'N',
    TO_DATE('20-JAN-1996', 'DD-MON-YYYY'),
    'in process'
);

SELECT
    *
FROM
    sales_order;

INSERT INTO sales_order (
    s_order_no,
    s_order_date,
    client_no,
    salesman_no,
    dely_type,
    billed_yn,
    dely_date,
    order_status
) VALUES (
    'O19001',
    TO_DATE('12-Jan-1996', 'DD-MON-YYYY'),
    'C00001',
    'S00001',
    'F',
    'N',
    TO_DATE('20-Jan-1996', 'DD-MON-YYYY'),
    'in process'
);

INSERT INTO sales_order (
    s_order_no,
    s_order_date,
    client_no,
    salesman_no,
    dely_type,
    billed_yn,
    dely_date,
    order_status
) VALUES (
    'O19002',
    TO_DATE('25-Jan-1996', 'DD-MON-YYYY'),
    'C00002',
    'S00002',
    'P',
    'N',
    TO_DATE('27-Jan-1996', 'DD-MON-YYYY'),
    'Canceled'
);

INSERT INTO sales_order (
    s_order_no,
    s_order_date,
    client_no,
    salesman_no,
    dely_type,
    billed_yn,
    dely_date,
    order_status
) VALUES (
    'O46865',
    TO_DATE('18-Feb-1996', 'DD-MON-YYYY'),
    'C00003',
    'S00003',
    'F',
    'Y',
    TO_DATE('20-Feb-1996', 'DD-MON-YYYY'),
    'Fulfilled'
);

INSERT INTO sales_order (
    s_order_no,
    s_order_date,
    client_no,
    salesman_no,
    dely_type,
    billed_yn,
    dely_date,
    order_status
) VALUES (
    'O19003',
    TO_DATE('03-Apr-1996', 'DD-MON-YYYY'),
    'C00001',
    'S00001',
    'F',
    'Y',
    TO_DATE('07-Apr-1996', 'DD-MON-YYYY'),
    'Fulfilled'
);

INSERT INTO sales_order (
    s_order_no,
    s_order_date,
    client_no,
    salesman_no,
    dely_type,
    billed_yn,
    dely_date,
    order_status
) VALUES (
    'O46866',
    TO_DATE('20-May-1996', 'DD-MON-YYYY'),
    'C00004',
    'S00002',
    'P',
    'N',
    TO_DATE('22-May-1996', 'DD-MON-YYYY'),
    'Canceled'
);

INSERT INTO sales_order (
    s_order_no,
    s_order_date,
    client_no,
    salesman_no,
    dely_type,
    billed_yn,
    dely_date,
    order_status
) VALUES (
    'O10008',
    TO_DATE('24-May-1996', 'DD-MON-YYYY'),
    'C00005',
    'S00004',
    'F',
    'N',
    TO_DATE('26-May-1996', 'DD-MON-YYYY'),
    'in process'
);

COMMIT;

DESC employee;

DROP TABLE employee;

CREATE TABLE employee (
    employee_id   VARCHAR(10),
    first_name    VARCHAR(50) NOT NULL,
    last_name     VARCHAR(50) NOT NULL,
    age           NUMBER(6) NOT NULL,
    gender        VARCHAR(6) NOT NULL,
    qualification VARCHAR(20) NOT NULL,
    salary        NUMBER(7, 2) NOT NULL,
    location      VARCHAR(20) NOT NULL,
    CONSTRAINT pk_employee_id PRIMARY KEY ( employee_id )
);

INSERT INTO employee VALUES (
    'MGS3498',
    'Rohit',
    'Thakur',
    23,
    'Male',
    'B.E. Comp',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3493',
    'Priyanka',
    'Tayde',
    25,
    'Female',
    'B.E. Comp',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3509',
    'Aruna',
    'Vasave',
    24,
    'Female',
    'B.E. Comp',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3499',
    'Ravina',
    'Suryawanshi',
    26,
    'Female',
    'B.E. Comp',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3505',
    'Kiran',
    'Kadam',
    24,
    'Male',
    'B.E. Extc',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3510',
    'Chaitanya',
    'Raykar',
    25,
    'Male',
    'B.E. Civil',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3496',
    'Santosh',
    'Honrao',
    24,
    'Male',
    'B.E. Mech',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3504',
    'Shubham',
    'Labde',
    24,
    'Male',
    'B.E. Mech',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3502',
    'Pravin',
    'Yadav',
    25,
    'Male',
    'B.E. Mech',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3516',
    'Tejas',
    'Zambare',
    23,
    'Male',
    'B.E. Elec',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3500',
    'Nitesh',
    'Subhedar',
    24,
    'Male',
    'B.E. Mech',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3508',
    'Vaibhav',
    'Tekude',
    23,
    'Male',
    'B.E. Mech',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3491',
    'Meraj',
    'Shaikh',
    24,
    'Male',
    'B.E. Mech',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3495',
    'Shashank',
    'Lokhande',
    24,
    'Male',
    'B.E. Extc',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3507',
    'Vinaya',
    'Naik',
    24,
    'Female',
    'B.E. Comps',
    29730,
    'Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3597',
    'Sanika',
    'Manchekar',
    23,
    'Female',
    'B.E. IT',
    29730,
    'Navi Mumbai'
);

INSERT INTO employee VALUES (
    'MGS3489',
    'Dinesh',
    'Saple',
    25,
    'Male',
    'B.E. Elec',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3492',
    'Paras',
    'Gharu',
    25,
    'Male',
    'B.E. Mech',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3490',
    'Mahima',
    'Dube',
    23,
    'Female',
    'M.Sc - IT',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3506',
    'Komal',
    'More',
    23,
    'Female',
    'BTech - Comp',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3503',
    'Rahul',
    'Bhatlavande',
    24,
    'Male',
    'B.E. Comp',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3515',
    'Harshal',
    'Bhagade',
    24,
    'Male',
    'B.E. Mech',
    29730,
    'Thane'
);

INSERT INTO employee VALUES (
    'MGS3494',
    'Pratap',
    'Bagwe',
    23,
    'Male',
    'BTech Mech',
    29730,
    'Mumbai'
);

SELECT
    *
FROM
    employee;

COMMIT;

SELECT
    employee_id,
    first_name,
    salary
FROM
    employee;

SELECT
    employee_id,
    first_name,
    last_name,
    salary
FROM
    employee;

SELECT
    employee_id,
    first_name
    || ' '
    || last_name AS full_name,
    salary
FROM
    employee;

SELECT
    employee_id,
    first_name
    || ' '
    || last_name AS full_name,
    salary,
    location
FROM
    employee
WHERE
    location = 'Thane';

UPDATE employee
SET
    salary = salary * 1.2
WHERE
    location = 'Thane';

COMMIT;

SELECT
    *
FROM
    employee;

UPDATE employee
SET
    salary = salary * 1.1
WHERE
    location = 'Mumbai';

COMMIT;

UPDATE employee
SET
    salary = salary * 1.2
WHERE
    location = 'Navi Mumbai';

SELECT
    *
FROM
    employee
ORDER BY
    location,
    first_name;

SELECT
    *
FROM
    employee
ORDER BY
    location DESC,
    first_name DESC;

SELECT
    *
FROM
    employee
WHERE
    qualification IN ( 'B.E. Mech', 'B.E. Elec' )
ORDER BY
    qualification;

SELECT
    *
FROM
    employee
WHERE
    qualification = 'B.E. Mech'
    OR qualification = 'B.E. Elec'
ORDER BY
    qualification;

SELECT
    *
FROM
    employee
WHERE
    qualification NOT IN ( 'B.E. Mech', 'B.E. Elec' )
ORDER BY
    qualification;

SELECT
    *
FROM
    employee
WHERE
    age NOT BETWEEN 20 AND 24
ORDER BY
    age;

SELECT
    *
FROM
    employee
WHERE
    last_name LIKE '%kar';

SELECT
    *
FROM
    employee
WHERE
    last_name NOT LIKE '%kar';

SELECT
    *
FROM
    employee
WHERE
        location = 'Mumbai'
    AND gender = 'Male'
ORDER BY
    first_name;

SELECT
    COUNT(gender) AS total_count
FROM
    employee
WHERE
        gender = 'Female'
    AND location = 'Thane';

SELECT
    SUM(salary) total_salary,
    AVG(salary) average_salary
FROM
    employee
WHERE
    location = 'Thane';

SELECT
    location,
    COUNT(first_name) employee_count
FROM
    employee
GROUP BY
    location;

SELECT
    qualification,
    SUM(salary) total_salary
FROM
    employee
GROUP BY
    qualification
ORDER BY
    total_salary;

SELECT
    qualification,
    SUM(salary) total_salary,
    COUNT(salary),
    MIN(salary),
    MAX(salary),
    AVG(salary)
FROM
    employee
GROUP BY
    qualification
ORDER BY
    total_salary;

SELECT
    qualification,
    SUM(salary) total_salary,
    COUNT(salary),
    MIN(salary),
    MAX(salary),
    AVG(salary)
FROM
    employee
GROUP BY
    qualification
HAVING
    SUM(salary) > 60000
ORDER BY
    total_salary;

CREATE TABLE emp_details (
    emp_id  NUMBER(5) NOT NULL,
    name    VARCHAR(20) NOT NULL,
    sal     NUMBER(10) NOT NULL,
    dept_id NUMBER(10) NOT NULL
);

DESC emp_details

DROP TABLE emp_details;

CREATE TABLE dept_details (
    dept_id   NUMBER(5) NOT NULL,
    dept_name VARCHAR(20) NOT NULL
);

DROP TABLE dept_details;

INSERT INTO dept_details VALUES (
    1,
    'IT'
);

INSERT INTO dept_details VALUES (
    2,
    'Admin'
);

INSERT INTO dept_details VALUES (
    3,
    'Finance'
);

INSERT INTO emp_details VALUES (
    101,
    'A',
    1000,
    1
);

INSERT INTO emp_details VALUES (
    102,
    'B',
    1000,
    1
);

INSERT INTO emp_details VALUES (
    103,
    'C',
    1000,
    2
);

INSERT INTO emp_details VALUES (
    104,
    'D',
    1000,
    2
);

INSERT INTO emp_details VALUES (
    105,
    'E',
    1000,
    3
);

SELECT
    *
FROM
    emp_details;

SELECT
    *
FROM
    dept_details;

SELECT
    *
FROM
    emp_details,
    dept_details;

COMMIT;

SELECT
    *
FROM
         emp_details
    JOIN dept_details ON emp_details.dept_id = dept_details.dept_id;

SELECT
    *
FROM
         emp_details e
    JOIN dept_details d ON e.dept_id = d.dept_id;

SELECT
    e.emp_id,
    e.sal,
    d.dept_id
FROM
         emp_details e
    JOIN dept_details d ON e.dept_id = d.dept_id;

SELECT
    *
FROM
    emp_details  e
    LEFT JOIN dept_details d ON e.dept_id = d.dept_id;

INSERT INTO emp_details VALUES (
    106,
    'F',
    1000,
    4
);

INSERT INTO emp_details VALUES (
    107,
    'G',
    1000,
    5
);

INSERT INTO dept_details VALUES (
    6,
    'Admin'
);

INSERT INTO dept_details VALUES (
    7,
    'HR'
);

COMMIT;

SELECT
    *
FROM
    emp_details  e
    LEFT JOIN dept_details d ON e.dept_id = d.dept_id;

SELECT
    *
FROM
    emp_details  e
    RIGHT JOIN dept_details d ON e.dept_id = d.dept_id;

SELECT
    *
FROM
    emp_details  e
    FULL JOIN dept_details d ON e.dept_id = d.dept_id;

CREATE TABLE employee_manager_details (
    employee_id NUMBER(10) NOT NULL,
    name        VARCHAR(20) NOT NULL,
    salary      NUMBER(10, 2) NOT NULL,
    manager_id  NUMBER(10)
);

INSERT INTO employee_manager_details VALUES (
    1,
    'Vivek',
    1000,
    NULL
);

INSERT INTO employee_manager_details VALUES (
    2,
    'Reema',
    1000,
    1
);

INSERT INTO employee_manager_details VALUES (
    3,
    'Seema',
    1000,
    2
);

INSERT INTO employee_manager_details VALUES (
    4,
    'Meena',
    1000,
    3
);

SELECT
    *
FROM
    employee_manager_details;

SELECT
    m.name || ' reports to '|| e.name employee_and_manager
FROM
         employee_manager_details e
    JOIN employee_manager_details m ON e.employee_id = m.manager_id;
    
SELECT * FROM dual;

SELECT SYSDATE FROM DUAL;

SELECT EXTRACT(year FROM SYSDATE) FROM dual;
SELECT EXTRACT(month FROM SYSDATE) FROM dual;
SELECT EXTRACT(day FROM SYSDATE) FROM dual;

SELECT SYSDATE + 1 FROM dual;
SELECT SYSDATE - 1 FROM dual;

SELECT ADD_MONTHS(SYSDATE, 1) FROM dual;

SELECT ADD_MONTHS(SYSDATE, -1) FROM dual;

SELECT LAST_DAY(SYSDATE) FROM dual;

SELECT LAST_DAY(TO_DATE('25-05-2022','DD-MM-YYYY')) FROM dual;

SELECT MONTHS_BETWEEN(TO_DATE('01-08-2022','DD-MM-YYYY'),
TO_DATE('01-05-2022','DD-MM-YYYY')) FROM dual;

SELECT NEXT_DAY(SYSDATE, 'SUNDAY') FROM dual;

SELECT LENGTH('ABC') FROM dual;

SELECT * FROM employee;

SELECT last_name, LENGTH(last_name) FROM employee
ORDER BY LENGTH(last_name),last_name;

SELECT CONCAT('Priyanka ', 'Tayde') FROM dual;

SELECT LOWER('PRIYANKA') FROM dual;
SELECT UPPER('priyanka') FROM dual;
SELECT TRIM('      HI     ') FROM dual;
SELECT LENGTH('      HI            ') FROM dual;
SELECT LENGTH(TRIM('      HI            ')) FROM dual;


CREATE TABLE sales_order_details (
s_order_no VARCHAR2(6),
product_no VARCHAR(6),
qty_ordered NUMBER(8),
qty_disp NUMBER(8),
product_rate NUMBER(10,2),    
CONSTRAINT fk_s_order_no FOREIGN KEY ( s_order_no )
REFERENCES sales_order ( s_order_no ),
CONSTRAINT fk_product_no FOREIGN KEY ( product_no )
REFERENCES product_master ( product_no )
);

CREATE TABLE challan_header (
challan_no VARCHAR2(6) CHECK(challan_no LIKE 'CH%'),
s_order_no VARCHAR2(6),
challan_date DATE NOT NULL,
billed_yn char(1) DEFAULT 'N' CHECK ( billed_yn = 'Y' OR billed_yn = 'N' ),
CONSTRAINT pk_challan_no_header PRIMARY KEY (challan_no),
CONSTRAINT fk_s_order_no_header FOREIGN KEY ( s_order_no )
REFERENCES sales_order ( s_order_no )
);

DROP TABLE challan_header;

CREATE TABLE challan_details (
challan_no VARCHAR2(6)CONSTRAINT fk_challan_no_c_details REFERENCES challan_header (challan_no),
product_no VARCHAR2(6)CONSTRAINT fk_product_no_c_details REFERENCES product_master (product_no),
qty_disp NUMBER(4,2) NOT NULL,
CONSTRAINT pk_challan_no_c_details PRIMARY KEY (challan_no, product_no)
);

insert into sales_order_details values('O19001','P00001',4,4,525);
insert into sales_order_details values('O19001','P07965',2,1,8400);
insert into sales_order_details values('O19001','P07885',2,1,5250);
insert into sales_order_details values('O19002','P00001',10,0,525);
insert into sales_order_details values('O46865','P07868',3,3,3150);
insert into sales_order_details values('O46865','P07885',3,1,5250);
insert into sales_order_details values('O46865','P00001',10,10,525);
insert into sales_order_details values('O46865','P03453',4,4,1050);
insert into sales_order_details values('O19003','P03453',2,2,1050);
insert into sales_order_details values('O19003','P06734',1,1,12000);
insert into sales_order_details values('O46866','P07965',1,0,8400);
insert into sales_order_details values('O46866','P07975',1,0,1050);
insert into sales_order_details values('O19003','P00001',10,4,525);
insert into sales_order_details values('O19003','P07975',5,3,1050);

select * from sales_order_details;

insert into challan_header values('CH9001','O19001','12-Dec-1995','Y');
insert into challan_header values('CH6865','O46865','12-Nov-1995','Y');
insert into challan_header values('CH3965','O10008','12-Oct-1995','Y');

SELECT * FROM challan_header;

insert into challan_details values('CH9001','P00001',4);
insert into challan_details values('CH9001','P07965',1);
insert into challan_details values('CH9001','P07885',1);
insert into challan_details values('CH6865','P07868',3);
insert into challan_details values('CH6865','P03453',4);
insert into challan_details values('CH6865','P00001',10);
insert into challan_details values('CH3965','P00001',5);
insert into challan_details values('CH3965','P07975',2);

SELECT * FROM challan_details;

INSERT INTO challan_details VALUES('CH9001','P00001',5);
INSERT INTO challan_details VALUES('P785341','P06734',9);
INSERT INTO challan_details VALUES('P00001','CH9001',1);

DROP TABLE challan_details;
DROP TABLE product_master;

SELECT NAME FROM client_master;
SELECT * FROM client_master;
SELECT name,city FROM client_master;
SELECT description FROM product_master;
SELECT name FROM client_master 
WHERE name LIKE '_a%';

SELECT * FROM client_master;

SELECT name ,city FROM client_master 
WHERE city LIKE '_a%';

SELECT name ,city FROM client_master 
WHERE city IN ('Bombay','Delhi','Madras');

SELECT name ,city FROM client_master 
WHERE city ='Bombay';

SELECT name ,bal_due FROM client_master 
WHERE bal_due > 10000;

SELECT * FROM sales_order 
WHERE s_order_date LIKE '%JAN%';

SELECT * FROM client_master 
WHERE client_no ='C00001' OR client_no ='C00002';

SELECT * FROM product_master
WHERE description IN ('1.44 Driver','1.22 Driver');
SELECT * FROM product_master
WHERE sell_price BETWEEN 2001 AND 4999;

SELECT product_master.*, sell_price*15  original_selling FROM product_master
WHERE sell_price > 1500;

ALTER TABLE product_master RENAME COLUMN "sell_price" TO "new_price";

SELECT * FROM product_master
WHERE cost_price < 1500;
SELECT * FROM product_master
ORDER BY description;
SELECT SQRT(sell_price) , sell_price FROM product_master;

SELECT name ,city FROM client_master 
WHERE city NOT IN ('Maharashtra');
SELECT description, sell_price FROM product_master WHERE description LIKE 'M%';
SELECT product_no, description, sell_price FROM product_master WHERE description LIKE 'M%';
SELECT * FROM sales_order WHERE order_status LIKE '%May%';

SELECT * FROM sales_order WHERE order_status = 'Canceled' AND s_order_date LIKE '%May%';
SELECT * FROM sales_order WHERE s_order_date LIKE '%May%' AND order_status IN( 'Canceled');
SELECT s_order_date , order_status FROM sales_order;

SELECT * FROM sales_order WHERE s_order_date LIKE '%MAY%' AND order_status IN( 'Canceled');
SELECT * FROM product_master WHERE description = '540 HDD' AND sell_price/(sell_price-100) ;