package com.sky.service;

import java.util.List;

import com.sky.domain.Actor;

public interface ActorService {
	public List<Actor> getActors();
}
