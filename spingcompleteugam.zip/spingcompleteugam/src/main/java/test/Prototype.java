package test;

public class Prototype {
String name;
public Prototype() {
	// TODO Auto-generated constructor stub
	System.out.println("in Prototype");
}
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

}
