package test;

public abstract class Parent {
	String name;
	int age;
	public Parent(){
		System.out.println("in const of parent");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		System.out.println("in name of Parent");
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}
