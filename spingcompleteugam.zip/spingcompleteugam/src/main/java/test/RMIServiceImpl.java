package test;

public class RMIServiceImpl implements RMIService {

	public RMIServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	//@Override
	public String getDisplay(String str) {
		// TODO Auto-generated method stub
		return "Hello"+ str;
	}

}
