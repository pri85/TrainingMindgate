package test;

public class RMIClient {
private RMIService rmiservice;

public void setRmiservice(RMIService rmiservice) {
	this.rmiservice = rmiservice;
}

public RMIService getRmiservice() {
	return rmiservice;
}

public void invoke(){
	rmiservice.getDisplay("zubin");
}
}
