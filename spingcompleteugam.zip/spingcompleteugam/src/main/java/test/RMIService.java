package test;

public interface RMIService {

	public String getDisplay(String str);
	
}
