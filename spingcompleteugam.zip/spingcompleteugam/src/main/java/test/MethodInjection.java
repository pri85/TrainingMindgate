package test;
public abstract class MethodInjection {
	public void invoke()
	{
		System.out.println(	getPrototype().getName());
	}
	public abstract InjectedPrototype getPrototype();

}
