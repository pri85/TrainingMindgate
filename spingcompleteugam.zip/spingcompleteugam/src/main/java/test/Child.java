package test;

public class Child {
	String name;
	int age;
	public Child(){
		System.out.println("in const of child");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		System.out.println("in name of child");
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}
