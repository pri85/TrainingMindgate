package test;

public class InjectedPrototype {
	public InjectedPrototype(){
		System.out.println("In const of prototype of injected");		
	}
private String name;
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

}
