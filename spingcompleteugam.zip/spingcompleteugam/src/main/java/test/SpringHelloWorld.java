package test;

import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SpringHelloWorld implements
BeanNameAware, InitializingBean, ApplicationContextAware{
	
	static{
		System.out.println("in static");
	}
	
	public void init(){
		System.out.println("in init");
		System.out.println("in init empid" + empid);
	empid = empid+1;
	}
		
	private int empid;
	private Prototype prototype;
	private String[] csvrow;
	private ApplicationContext 	applicationContext;
	
	
	private String beanName;
	
	
	
	public String getBeanName() {
		return beanName;
	}
	public Prototype getPrototype() {
		return prototype;
	}
	
	@Autowired
	public void setPrototype(Prototype prototype) {
		this.prototype = prototype;
	}
	public SpringHelloWorld()
	{
		System.out.println("Hello Spring 3.0 const" + empid + getAccounts());
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		System.out.println("in emp id set");
		this.empid = empid;
	}
	  private Map<String, Float> 
	  accounts;
	    
	    public void setAccounts(Map<String, Float> accounts) {
	        this.accounts = accounts;
	    }
	    public Map<String, Float> getAccounts() {
	        return accounts;
	    }
	private static SpringHelloWorld sp = null;
	
	
	public void sayHello(){

		System.out.println("Hello Spring 3.0" + empid + getAccounts());

		}
	 public static SpringHelloWorld createInstance(){
		 System.out.println("Hello Spring 3.0 const create ins");
		 if (sp == null){
			 sp = new SpringHelloWorld();
			 return sp;
		 }
		 else{
			 return sp;
		 }
			 
			 
	 }
	public void setCsvrow(String[] csvrow) {
		this.csvrow = csvrow;
	}
	public String[] getCsvrow() {
		return csvrow;
	}
	//@Override
	public void setBeanName(
			String beanName) {
		// TODO Auto-generated method stub
		System.out.println
		("In bean Name");
	this.beanName = beanName;	
	}
	//@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println(
				"After prop");
		empid = empid+1;
	}
//	@Override
	public void setApplicationContext(ApplicationContext
			applicationContext)
			throws BeansException {
		this.applicationContext= applicationContext;
		
	}
	 }

