package com.sky.jdbc.domain;

public class Product extends BaseEntity {


	private String productName;

	private int price;


	private Category category;
	
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		if(price >0 )
			this.price = price;
		else
			this.price = 0;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}





}
