package com.sky.jdbc.domain;

import java.util.ArrayList;
import java.util.List;

public class Division extends BaseEntity {

	List<Category> categories = new ArrayList<Category>();

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
	
	public void addCategories(Category category){
		this.categories.add(category);
	}
}
