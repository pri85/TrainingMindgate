package com.sky.jdbc.domain;

public class Category extends BaseEntity {


	private String categoryName;
	public Category() {
		super();
	}
	// Many-one
	private Division division;


	public Division getDivision() {
		return division;
	}

	public void setDivision(Division division) {
		this.division = division;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


}
