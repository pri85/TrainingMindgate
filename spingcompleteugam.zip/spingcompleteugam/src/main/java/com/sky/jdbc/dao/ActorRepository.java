package com.sky.jdbc.dao;

import java.util.List;

import com.sky.jdbc.domain.Actor;

public interface ActorRepository {
	public List findAllActors();
	public void addActor(Actor actor);
	public Actor findActorByName(String firstName);
}
