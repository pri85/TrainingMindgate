package com.sky.jdbc.service;

import java.util.List;

import com.sky.jdbc.domain.Actor;



public interface ActorService {
	public List findAllActors();
	public void addActor(Actor actor);
}
