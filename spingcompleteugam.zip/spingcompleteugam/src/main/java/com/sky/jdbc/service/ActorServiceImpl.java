package com.sky.jdbc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sky.jdbc.dao.ActorRepository;
import com.sky.jdbc.domain.Actor;



@Service("actorService")
public class ActorServiceImpl
implements ActorService {
	
	@Autowired 
	@Qualifier(value = "actorRepository")
	ActorRepository actRep;
	
	public ActorRepository getActRep() {
		return actRep;
	}

	public void setActRep(ActorRepository actRep) {
		this.actRep = actRep;
	}

	//@Override
	@Transactional(propagation=Propagation.SUPPORTS)
	public List findAllActors() {
		return actRep.findAllActors();
	}

//@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public void addActor(Actor actor) {
		if(actRep.findActorByName(
		actor.getFirsName()) == null)
		actRep.addActor(actor);
	}

}
