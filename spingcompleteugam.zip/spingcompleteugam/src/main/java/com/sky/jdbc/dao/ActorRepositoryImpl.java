package com.sky.jdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.sky.jdbc.domain.Actor;




@Repository(value = "actorRepository")
public class ActorRepositoryImpl implements ActorRepository {
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource ds) {
		jdbcTemplate= new JdbcTemplate(
				ds);
	}

	public void init(){
		jdbcTemplate.update(
		"create table actor (first_name VARCHAR(256) ,last_name VARCHAR(256) )");
		jdbcTemplate.update("insert into actor values('abc' , xyz')");
		
	}	
	
	private static final class ActorRowMapper
	implements RowMapper<Actor> {
		
		public Actor 
	mapRow(ResultSet rs, int rownum) 
		throws SQLException {
Actor actor = new Actor();
actor.setFirsName(rs.getString("first_name"));
actor.setLastName(rs.getString("last_name"));
return actor;
		}
	}
	
	
	public List findAllActors() {
		return this.jdbcTemplate.
		query(
	"select first_name, last_name" +
	" from actor", new ActorRowMapper());
	}
	
	public void addActor(Actor actor) {
		//this.jdbcTemplate.execute("insert into actor values(\"amir\",\"khan\")");
	}

	public Actor findActorByName(String firstName) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
