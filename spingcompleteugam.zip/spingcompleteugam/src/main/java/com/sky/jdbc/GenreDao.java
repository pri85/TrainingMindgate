package com.sky.jdbc;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.SimpleJdbcOperations;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.sky.domain.Genre;

public class GenreDao  {
private SimpleJdbcTemplate jdbcTemplate ;
private GenreQuery genreQuery;
public GenreQuery getGenreQuery() {
	return genreQuery;
}
public void setGenreQuery(GenreQuery genreQuery) {
	this.genreQuery = genreQuery;
}
public void setDataSource (DataSource ds){
	jdbcTemplate = new SimpleJdbcTemplate(ds);
}
public int getGenreCount(){
	String sql = "Select count(*) from Genre";
	return jdbcTemplate.queryForInt(sql);
}
public List<Genre> getAllGenere(){
	return genreQuery.execute();
}
}
