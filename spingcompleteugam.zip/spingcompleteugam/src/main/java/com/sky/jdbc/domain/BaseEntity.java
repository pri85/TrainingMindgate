package com.sky.jdbc.domain;

import java.util.HashMap;
import java.util.Map;

public abstract class BaseEntity {
	
	private static int nextGenId;

	private static Map<String,Integer> nextGenMap= 
			new HashMap<String, Integer>();
	static{
		nextGenId =10;
		System.out.println("in Static block");
	}

	public BaseEntity() {
		super();
		incrementId();
	}
	
	
	
	protected Integer id;
	protected void incrementId(){
		//this.id = nextGenId;
		//++nextGenId;
		//this.id = UUID.randomUUID().toString();
		if(nextGenMap.get(this.getClass().getName()) != null)
			this.id  = nextGenMap.get(this.getClass().getName());
		else{
			this.id  = 10;
		
		}
		nextGenMap.put(this.getClass().getName(), this.id+10);
		
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	

}
