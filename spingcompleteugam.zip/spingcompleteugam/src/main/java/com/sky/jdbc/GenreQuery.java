package com.sky.jdbc;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import com.sky.domain.Genre;


import javax.sql.DataSource;
import java.sql.Types;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GenreQuery extends MappingSqlQuery<Genre> {
  private static String SQL_PERFORMANCE_QUERY =
	  "select id, name from Genre";
  //"select id, name from Genre where id = ?";
  public GenreQuery(DataSource ds) {
    super(ds, SQL_PERFORMANCE_QUERY);
    //declareParameter(new SqlParameter("id", Types.INTEGER));
    compile();
  }


  public Genre mapRow(ResultSet rs, int rowNumber) throws SQLException {
	  com.sky.domain.Genre genre = new com.sky.domain.Genre();
	  genre.setId(rs.getInt("id"));
	  genre.setName(rs.getString("name"));
    return genre;
 }

}
