package com.sky.jpa.domain;

import java.io.Serializable;



//@Entity
//@Table(name = "Bank_Account_spring")
public class Account implements Serializable {
	public Account() {
		super();
	}
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Account(String accountNo, double balance) {
		super();
		AccountNo = accountNo;
		this.balance = balance;
	}

	//@Id
	String AccountNo;
	double balance;
	
	public String getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(String accountNo) {
		AccountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

}
