package com.sky.beanpostprocessor;

import java.util.Map;

public class EmployeeService implements StateCodeAware {

	private Map<String, String> stateCode;
	//@Override
	public void setStateCode(Map<String, String> stateCode) {
		// TODO Auto-generated method stub
		this.stateCode = stateCode;
	}
	
	public void printState(String code){
		System.out.println("state" + stateCode.get(code));
	}
}