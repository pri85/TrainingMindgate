package com.sky.beanpostprocessor;

import java.util.Map;

import org.aspectj.weaver.patterns.IScope;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class MapPostProcessor implements BeanPostProcessor {

	private Map<String, String> stateCode ;
	
	public Map<String, String> getStateCode() {
		return stateCode;
	}

	public void setStateCode(Map<String, String> stateCode) {
		this.stateCode = stateCode;
	}

//	@Override
	public Object postProcessAfterInitialization
	(Object bean, String name)
			throws BeansException {
		// TODO Auto-generated method stub
		if(bean instanceof StateCodeAware){
			StateCodeAware iaware =
				(StateCodeAware)bean;
			iaware.setStateCode(stateCode);
		}
		return bean;
	}

//	@Override
	public Object postProcessBeforeInitialization
	(Object bean, String name)
			throws BeansException {
		// TODO Auto-generated method stub
		return bean;
	}

}
