package com.sky.beanpostprocessor;

import java.util.Map;

public interface StateCodeAware {

	public void setStateCode(Map<String,String> stateCode);
}
