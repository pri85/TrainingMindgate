package com.sky.service;

import com.sky.domain.Genre;
import com.sky.orm.GenreDaoHibernate;

public class GenreService {
private GenreDaoHibernate genreDaoHibernate;

public void setGenreDaoHibernate(GenreDaoHibernate genreDaoHibernate) {
	this.genreDaoHibernate = genreDaoHibernate;
}

public GenreDaoHibernate getGenreDaoHibernate() {
	return genreDaoHibernate;
}

public void saveGenre(Genre genre){
	genreDaoHibernate.saveGenre(genre);
}

}
