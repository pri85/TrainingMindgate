package com.sky.factorybean;

import org.springframework.beans.factory.FactoryBean;

public class JNDIProxyBean implements FactoryBean<SQLDataSource>{

	//@Override
	public SQLDataSource getObject() throws Exception {
		// TODO Auto-generated method stub
		SQLDataSource  ds =new SQLDataSource();
		ds.setName("SQL DS");
		return ds;
	}

//	@Override
	public Class<?> getObjectType() {
		// TODO Auto-generated method stub
		return SQLDataSource.class;
	}

	//@Override
	public boolean isSingleton() {
		// TODO Auto-generated method stub
		return true;
	}

}
