package com.sky.factorybean;

public class WeatherDao {

	private SQLDataSource sqlDataSource;

	public SQLDataSource getSqlDataSource() {
		return sqlDataSource;
	}

	public void setSqlDataSource(SQLDataSource sqlDataSource) {
		this.sqlDataSource = sqlDataSource;
	}
	
	public void display(){
		System.out.println(sqlDataSource);
	}
	
}
