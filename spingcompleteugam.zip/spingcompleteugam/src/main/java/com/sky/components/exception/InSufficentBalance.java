package com.sky.components.exception;

public class InSufficentBalance extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7664950193368369527L;

	public InSufficentBalance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InSufficentBalance(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
