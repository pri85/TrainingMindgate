package com.sky.components.dao;

import com.sky.jpa.domain.Account;

public interface AccountManagementDao {
	
public void createAccount(Account account);
public void updateAccount(Account account);
public double getAccountBalance(String accountNo);	


}
