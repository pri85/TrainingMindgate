package com.sky.components;



import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import test.Prototype;

@Component(value = "annocomponent")
public class AnnotatedComponent {
String name;


Prototype prototype;

public Prototype getPrototype() {
	return prototype;
}

@Resource
//@Autowired
//@Qualifier(value="pro")
//@Resource
public void setPrototype(Prototype prototype) {
	this.prototype = prototype;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}


}
