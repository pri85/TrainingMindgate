package com.sky.components.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sky.components.dao.AccountManagementDao;
import com.sky.components.exception.InSufficentBalance;
import com.sky.jpa.domain.Account;

@Service
@Transactional
public class AccountManagementService {

@Autowired
private AccountManagementDao dao;

@Transactional
(propagation=Propagation.REQUIRES_NEW)
public void createNewAccount(Account account){
	 dao.createAccount(account);
}
@Transactional
(propagation=Propagation.REQUIRED)
public void depositMoney(
		String accountNo, double ammount) throws InSufficentBalance{
	//throw new InSufficentBalance("wrong trans");
	double currentBalance = balanceCheck(accountNo);
	dao.updateAccount(new Account(accountNo, currentBalance+ammount));
}

@Transactional(propagation
		=Propagation.REQUIRED
		,rollbackFor=InSufficentBalance.class)
public void widthdrawMoney
	(String accountNo, double ammount)
	throws InSufficentBalance{
	
	double currentBalance = balanceCheck(accountNo);
	if(currentBalance < ammount)
		throw new InSufficentBalance("Less Banlance Found");
	dao.updateAccount(new Account(accountNo, currentBalance- ammount));
	
}
@Transactional(
propagation=Propagation.REQUIRES_NEW,
rollbackFor=InSufficentBalance.class)
public void transferMoney(String accountNofrom,
		String accountNoto,
		double ammount) throws InSufficentBalance{
		widthdrawMoney(accountNofrom, ammount);
		depositMoney(accountNoto,  ammount);
	
}
@Transactional(
		propagation=Propagation.SUPPORTS)
public double balanceCheck(String accountNo){
	return dao.getAccountBalance(accountNo);
}
}
