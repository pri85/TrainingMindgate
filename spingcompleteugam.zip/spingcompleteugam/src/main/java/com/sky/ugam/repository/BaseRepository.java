package com.sky.ugam.repository;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;


public class BaseRepository {
	
	private static BasicDataSource dataSource;
	static{
		Properties properties= new Properties();
		try {
			properties.
			load(BaseRepository.class.getResourceAsStream("/connection.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dataSource =new BasicDataSource();
		dataSource.setDriverClassName(properties.getProperty("driver"));
		dataSource.setUrl(properties.getProperty("URL"));
		dataSource.setUsername(properties.getProperty("userName"));
		dataSource.setPassword(properties.getProperty("password"));

	}
	protected Connection  getConnection() throws SQLException{
		Connection con =dataSource.getConnection(); 
		con.setAutoCommit(false);
		return con;
		
			
	}

	
}
