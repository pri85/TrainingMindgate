package com.sky.ugam.repository;

import java.util.ArrayList;
import java.util.List;

import com.sky.jdbc.domain.Product;

public class ProductRepositoryImpl implements ProductRepository {

	// Bad way .. will change to JDBC later
	private static List<Product> products = new ArrayList<Product>();
	
	public void addProduct(Product product) {
		System.out.println("in repository");
		products.add(product);

	}

	
	public List<Product> getProducts() {
			return products;
	}

	
	public Product getProductById(int  id) {
		for (Product product : products) {
			if(product.getId() == id)
				return product;
		}
		return null;
	}

}
