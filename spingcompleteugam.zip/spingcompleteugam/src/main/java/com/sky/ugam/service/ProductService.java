package com.sky.ugam.service;

import java.util.List;

import com.sky.jdbc.domain.Product;

/**
 * @author zubin
 *
 */
public interface ProductService {

	/**
	 * @param product
	 */
	public void addProduct(Product product);
	public List<Product> getProducts();
	public Product getProductById(Integer id) ;
}
