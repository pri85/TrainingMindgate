package com.sky.ugam.service;

import java.util.List;

import com.sky.jdbc.domain.Product;
import com.sky.ugam.repository.ProductRepository;
import com.sky.ugam.repository.ProductRepositoryImpl;

public class ProductServiceImpl implements ProductService {

	private ProductRepository productRepository;// = new ProductRepositoryImpl();
	
	
	//@Override
	public void addProduct(Product product) {
		System.out.println("in Service");
		if(product.getPrice() > 20)
			productRepository.addProduct(product);
	}

	//@Override
	public List<Product> getProducts() {
			return productRepository.getProducts();
	}

	/**
	 * @return the productRepository
	 */
	public ProductRepository getProductRepository() {
		return productRepository;
	}

	/**
	 * @param productRepository the productRepository to set
	 */
	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	//@Override
	public Product getProductById(Integer id) {
		return productRepository.getProductById(id);
	}

}
