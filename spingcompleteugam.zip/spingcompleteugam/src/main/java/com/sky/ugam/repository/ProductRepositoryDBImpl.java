package com.sky.ugam.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sky.jdbc.domain.Product;

public class ProductRepositoryDBImpl extends BaseRepository implements ProductRepository {

	private static String INSERT_PRODUCT_SQL = "insert into products(productName,productprice) values(?,?)";
	private static String ALL_PRODUCT_SQL = "Select productsid, productName,productprice  from products";
	private static String PRODUCT_BYID_SQL = "{call getproductById(?,?,?) }";
	
	public void addProduct(Product product) {
		Connection connection = null;
		try {
			connection = super.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PRODUCT_SQL);
			preparedStatement.setString(1, product.getProductName());
			preparedStatement.setInt(2, product.getPrice());
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		

	}

	
	public List<Product> getProducts() {
		
		Connection connection = null;
		try {
			List<Product> products = new ArrayList<Product>();
			connection = super.getConnection();
			
			PreparedStatement preparedStatement = connection.prepareStatement(ALL_PRODUCT_SQL);
			
			ResultSet rs = preparedStatement.executeQuery();
	        while (rs.next()) {
	        	Product product= new Product();
	        	product.setId(rs.getInt("productsid"));
	        	product.setProductName(rs.getString("productName"));
	        	product.setPrice(rs.getInt("productprice"));
	        	products.add(product);
	        }
	        return products;
	      
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		e.printStackTrace();
	}
	finally{
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return null;
	}
	/*
	 * (non-Javadoc)
	 * @see com.sky.repository.ProductRepository#
	 * getProductById(int)
	 * 
CREATE  PROCEDURE `getproductById`(
IN p_id  INT,
OUT o_productname   VARCHAR(255),
out	 o_price  INT)
BEGIN
SELECT productName, productprice
  INTO o_productname, o_price
  FROM  products WHERE  productsId = p_id;
END
	 */
	public Product getProductById(int  id) {
		Connection connection = null;
		try {
			connection = super.getConnection();
			CallableStatement callableStatement = connection.prepareCall(PRODUCT_BYID_SQL);
			callableStatement.setInt(1, id);
			callableStatement.registerOutParameter(2, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(3, java.sql.Types.INTEGER);
			callableStatement.execute();
			Product product= new Product();
        	product.setId(id);
        	product.setProductName(callableStatement.getString(2));
        	product.setPrice(callableStatement.getInt(3));
        	return product;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		return null;
	}

}
