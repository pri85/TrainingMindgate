package com.sky.ugam.repository;

import java.util.List;

import com.sky.jdbc.domain.Product;



/**
 * @author zubin
 *
 */
public interface ProductRepository {

	/**
	 * @param product
	 */
	public void addProduct(Product product);
	public List<Product> getProducts();
	public Product getProductById(int id);
}
