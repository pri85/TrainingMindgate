package com.sky.orm;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.sky.domain.Genre;

public class GenreDaoHibernate 
extends HibernateDaoSupport {
	public void saveGenre(Genre genre){
		getHibernateTemplate().save(genre);
	}
	public List<Genre> getAllGenre(){
		return (List<Genre>)getHibernateTemplate().find("from Genre");
	}

}
