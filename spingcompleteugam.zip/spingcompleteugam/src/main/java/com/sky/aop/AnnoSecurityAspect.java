package com.sky.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class AnnoSecurityAspect{

@Before("execution(* com.sky.aop.ApplicationService." +
		"*(..))")
public void VerifyApplicationForm(){
	System.out.println("Ina anno before call");
	
}


@After("execution(* com.sky.aop.ApplicationService." +
		"*(..))")
public void processResults(){
	System.out.println("processResults");
	
}

}
