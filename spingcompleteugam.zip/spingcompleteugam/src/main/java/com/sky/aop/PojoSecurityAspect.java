package com.sky.aop;


public class PojoSecurityAspect{

public void VerifyApplicationForm(){
	System.out.println("In pojo before call");
	
}

public void processResults(){
	System.out.println("In pojo after call");
	
}

}
