package com.sky.aop;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;

public class ApplicationAdvice implements MethodBeforeAdvice,
AfterReturningAdvice{

	private MessageAspect messageAspect; 
	public MessageAspect getMessageAspect() {
		return messageAspect;
	}

	public void setMessageAspect(MessageAspect messageAspect) {
		this.messageAspect = messageAspect;
	}

	//@Override
	public void afterReturning(Object returnValue, Method method,
			Object[] args, Object target) throws Throwable {
		// TODO Auto-generated method stub
		messageAspect.processResults();
		//System.out.println("processResults");
		
	}

	//@Override
	public void before(Method method, Object[] args, Object target)
			throws Throwable {
		// TODO Auto-generated method stub
		//System.out.println("fillApplicationForm");
		messageAspect.VerifyApplicationForm();
	}

	

	
}
