package com.sky.aop;

public class MessageAspect{

public void VerifyApplicationForm(){
	System.out.println("fillApplicationForm");
	
}

public void processResults(){
	System.out.println("processResults");
	
}

}
