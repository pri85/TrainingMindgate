package com.sky.aop;

public class ApplicationServiceImpl implements ApplicationService {

	//@Override
	public void processApplication() {
		// TODO Auto-generated method stub
		System.out.println(" Process ApplicationForm");

	}

}
