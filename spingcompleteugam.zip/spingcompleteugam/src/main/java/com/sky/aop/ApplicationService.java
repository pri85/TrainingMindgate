package com.sky.aop;

public interface ApplicationService {
public void processApplication();
}
