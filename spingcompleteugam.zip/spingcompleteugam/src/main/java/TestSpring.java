import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test.SpringHelloWorld;

import com.sky.jdbc.domain.Product;
import com.sky.ugam.service.ProductService;

public class TestSpring {
	static Logger log = Logger.getLogger(TestSpring.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("before call");
		log.info("Hi from Logger");
		/*
		XmlBeanFactory beanFactory = 
		new XmlBeanFactory(
		new ClassPathResource("SpringHelloWorld1.xml"));
		 */
		ApplicationContext beanFactory =
			new ClassPathXmlApplicationContext("SpringHelloWorld.xml");
		System.out.println("after call");
		SpringHelloWorld myBean = (SpringHelloWorld) beanFactory
		.getBean("SpringHelloWorldBean");
		SpringHelloWorld myBean1 = (SpringHelloWorld) beanFactory
		.getBean("SpringHelloWorldBean");
		
		ProductService productService = (ProductService) beanFactory.getBean("productService");
		Product product = new Product();
		product.setProductName("p1");
		product.setPrice(1222);
		productService.addProduct(product);

		//beanFactory.getBean("server");
		//	beanFactory.getBean("wsserver");
/*
		Prototype myprotoype = (Prototype) 
		beanFactory.getBean("prototype");
		Prototype myprotoype1 = (Prototype) 
		beanFactory.getBean("prototype");

		myprotoype.setName("kkk");
	*/	
		/*
		System.out.println(
				myBean1.getPrototype().getName());
		myBean.sayHello();
		//myBean.getPrototype().setName("ddddd");
		System.out.println(
				myBean1.getPrototype().getName());
		System.out.println(
				myBean1.getPrototype().getName());

		Child c = (Child)beanFactory.getBean("child");
		System.out.println(c.getName());

		// Method Inject
		MethodInjection me = (MethodInjection)beanFactory.getBean("methodInvoke");
		me.invoke();
		MethodInjection me1 = (MethodInjection)beanFactory.getBean("methodInvoke");
		me1.invoke();
		// Factory Bean
		WeatherDao weatherDao = 
			(WeatherDao)
			beanFactory.getBean("weatherDao");
		System.out.println(weatherDao.getSqlDataSource().getName());
		//XSD
		SimpleDateFormat dt = (SimpleDateFormat)
		beanFactory.getBean("dateFormat");
		System.out.println(dt.toPattern());
	
		//Annotation 
		AnnotatedComponent ann = (AnnotatedComponent)
		beanFactory.getBean("annocomponent");
		//System.out.println(ann.getPro().getName());
		System.out.println("In annotation " + ann.getPrototype().getName());
		
		//Message Properties
		MessageProperties msgprop = (MessageProperties)
		beanFactory.getBean("messageproperties");
		System.out.println(msgprop.printMessage());
		
		//Bean Processing
		EmployeeService empService = (EmployeeService)
		beanFactory.getBean("empService");
		empService.printState("MH");

		//Spring AOP
		ApplicationService service = (ApplicationService)
		beanFactory.getBean("applicationService");
		service.processApplication();

		//Aspect J
		ApplicationService annoservice = (ApplicationService)
		beanFactory.getBean("anoapplicationService");
		annoservice.processApplication();
		

		//Aspect AOP tags
		ApplicationService pojoservice = 
		(ApplicationService)
		beanFactory.getBean("pojoapplicationService");
		pojoservice.processApplication();
		*/
		//JDBC
		/*
		GenreDao genredao = (GenreDao)beanFactory.getBean
		("genreDao");
		System.out.println(genredao.getGenreCount());
		List<Genre> genres =genredao.getAllGenere();
		System.out.println(genres);
		Iterator<Genre> iter = genres.iterator();
		while(iter.hasNext()){
			Genre genre = iter.next();
			System.out.println(genre.getName());
		}
		*/
		//Hibernate
		/*
		Genre genre = new Genre();
		genre.setName("new Show");
		GenreService genereservice = (GenreService)
		beanFactory.getBean("genreService");
		*/
		//genereservice.saveGenre(genre);
		/*
		// Transction Management
		Account accountA = new Account();
		accountA.setAccountNo("123");
		accountA.setBalance(3000);
		Account accountB = new Account();
		accountB.setAccountNo("345");
		accountB.setBalance(3000);
		AccountManagementService accountService= 
			(AccountManagementService)
			beanFactory.getBean(AccountManagementService.class);
		//accountService.createNewAccount(accountA);
		//accountService.createNewAccount(accountB);
		*/
		/*
		try {
		
		//	accountService.widthdrawMoney("345", 1000);
		//
		//	accountService.widthdrawMoney("123", 1000);
		//	accountService.widthdrawMoney("123", 1000);
			
//			accountService.transferMoney("123", "345", 1000);
	
	} catch (InSufficentBalance e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//JPA
		/*
		GenreJPADao jpadao = (GenreJPADao)beanFactory
		.getBean("genreJPADao");
		GenreJPA genrejpa = new GenreJPA();
		genrejpa.setName("zubin");
		jpadao.addGenre(genrejpa);
		*/
		//JMS
		/*
		JMSSender sender = (JMSSender)beanFactory
		.getBean("JMSSendder");
		sender.sendMessage();
		//sender.recieveMessage();
*/
		 
	}
}
