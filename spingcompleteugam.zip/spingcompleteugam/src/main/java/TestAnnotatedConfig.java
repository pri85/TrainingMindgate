import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import test.SpringConfig;
import test.SpringHelloWorld;


public class TestAnnotatedConfig {
	public static void main(String[] args) {
AnnotationConfigApplicationContext 
context
= new 
AnnotationConfigApplicationContext(
		SpringConfig.class);
SpringHelloWorld hello =
	(SpringHelloWorld)context.
	getBean("SpringHello");
SpringHelloWorld hello1 =
	(SpringHelloWorld)context.
getBean(SpringHelloWorld.class);
System.out.println(hello.getEmpid());
}
}
