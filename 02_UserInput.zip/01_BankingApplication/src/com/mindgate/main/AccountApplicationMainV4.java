package com.mindgate.main;

import com.mindgate.pojo.Savings;

public class AccountApplicationMainV4 {
	public static void main(String[] args) {
		Savings savings = new Savings(101, "Vivek Gohil", 1000, false);
	}

}
