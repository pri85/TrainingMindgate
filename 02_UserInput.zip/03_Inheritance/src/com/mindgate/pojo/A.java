package com.mindgate.pojo;

public class A {

//	public void display() {
//		System.out.println("hi");
//	}
	public A() {
		System.out.println("Hi");
	}

	public A(int x) {
		System.out.println("hi" + x);
	}

}
