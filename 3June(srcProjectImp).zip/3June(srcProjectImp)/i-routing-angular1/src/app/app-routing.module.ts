import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddnewemployeeComponent } from './addnewemployee/addnewemployee.component';

const routes: Routes = [
  {path:'addemployee', component: AddnewemployeeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
