import { TestBed } from '@angular/core/testing';

import { EmployeeCRUDServiceService } from './employee-crudservice.service';

describe('EmployeeCRUDServiceService', () => {
  let service: EmployeeCRUDServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeCRUDServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
