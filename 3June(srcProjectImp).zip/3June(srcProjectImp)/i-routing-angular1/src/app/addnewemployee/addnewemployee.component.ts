import { Component, OnInit } from '@angular/core';
import { Employee } from '../pojo/employee';
import { EmployeeCRUDServiceService } from '../services/employee-crudservice.service';

@Component({
  selector: 'app-addnewemployee',
  templateUrl: './addnewemployee.component.html',
  styleUrls: ['./addnewemployee.component.css']
})
export class AddnewemployeeComponent implements OnInit {

  employee : Employee = new Employee();

  constructor(private employeeService : EmployeeCRUDServiceService) { }

  ngOnInit(): void {
  }

  onFormSubmit(){
    console.log(this.employee);
    this.employeeService.addEmployee(this.employee).subscribe(
      data => {
        console.log(data);
        
      }
    );
    alert("Form Submitted Successfully");
    
  }


}
