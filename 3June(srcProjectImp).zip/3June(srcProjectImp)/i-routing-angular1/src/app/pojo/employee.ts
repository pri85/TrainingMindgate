export class Employee{
    employeeId: number = 0;
    name: string = "";
    salary: number = 0.0;
}